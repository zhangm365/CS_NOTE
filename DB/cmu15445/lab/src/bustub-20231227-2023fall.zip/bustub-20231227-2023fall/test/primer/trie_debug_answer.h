#include "common/exception.h"

auto Case1CorrectAnswer() -> int {
  throw bustub::NotImplementedException(
      "The correct answer is hidden. Submit to Gradescope to see if your answer is correct.");
}

auto Case2CorrectAnswer() -> int {
  throw bustub::NotImplementedException(
      "The correct answer is hidden. Submit to Gradescope to see if your answer is correct.");
}

auto Case3CorrectAnswer() -> int {
  throw bustub::NotImplementedException(
      "The correct answer is hidden. Submit to Gradescope to see if your answer is correct.");
}
