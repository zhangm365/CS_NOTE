#include "binder/bound_statement.h"

namespace bustub {

BoundStatement::BoundStatement(StatementType type) : type_(type) {}

}  // namespace bustub
