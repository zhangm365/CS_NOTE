#!/bin/bash
sleep 3
cd tests/p2a-test
ls test2

