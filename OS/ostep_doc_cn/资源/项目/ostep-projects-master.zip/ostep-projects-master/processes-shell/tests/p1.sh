#! /bin/bash
cd tests/p2a-test
ls
